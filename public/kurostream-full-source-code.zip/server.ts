import http from 'node:http';
import path from 'node:path';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import { attachWatchPartyWebSocket, createKuroStreamApp } from './src/server/app';

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';

async function startServer() {
  const { app, hub } = createKuroStreamApp();
  const server = http.createServer(app);

  // Mount WebSocket server on /ws/party
  attachWatchPartyWebSocket(server, hub);

  if (!IS_PROD) {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true' ? { server } : false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  // Periodically prune expired watch party rooms
  setInterval(() => hub.pruneExpiredRooms(), 10 * 60 * 1000).unref();

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`KuroStream full-stack server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start KuroStream server:', err);
  process.exit(1);
});
