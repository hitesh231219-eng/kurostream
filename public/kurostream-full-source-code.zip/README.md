# KuroStream — Anime Streaming, Manga Reader, Watch Parties & Full UI Customizer

Full-stack anime & manga platform powered by live **AniList GraphQL**, **Firebase Auth & Cloud Firestore**, real-time **WebSocket Watch Parties**, **NekoStream Pahe + Kwik + AnimeTosho + Nyaa + SubsPlease** verified download resolution, a **zero-limits Full UI Customization Studio**, and a **Windows Desktop Edition** (Electron + Edge/Chrome App-Mode installer).

## Live Links & Mirrors

- **GitHub Repository:** https://github.com/hitesh231219-eng/kurostream
- **GitHub Pages (Static):** https://hitesh231219-eng.github.io/kurostream/
- **Primary Full-API Vercel Mirrors:**
  - https://kurostream-m1.vercel.app
  - https://kurostream-m2.vercel.app
  - https://kurostream-m3.vercel.app
  - https://kurostream-m4.vercel.app
  - https://kurostream-m5.vercel.app
- **Netlify Mirrors:**
  - https://kurostream-app.netlify.app
  - https://kurostream-m1.netlify.app through https://kurostream-m5.netlify.app

## Features

- **Zero-Limits Full UI Customization Studio (`/settings` or `Ctrl+,`):** Customize Light/Dark schemes, arbitrary hex palettes, 3-stop gradients, full-bleed custom wallpaper URLs, arbitrary Google Fonts, base scale/tracking/line-height, top/sidebar/bottom-dock/hidden navigation modes, hero layouts (`Full`, `Compact`, `Split`, `Minimal`, `Hidden`), carousel vs 2–8 column grids, card aspect ratios/hover effects/filters, home section reordering/renaming/hiding, saved theme profiles, JSON import/export, and unrestricted live CSS injection.
- **Verified Anime Downloads & NekoStream Pahe Tracer:** Resolves identity-matched episode & batch releases across NekoStream Pahe -> Kwik, AnimeTosho, Nyaa, NekoBT, and SubsPlease using verified AniList, MyAnimeList, and AniDB IDs.
- **Multi-Server Player & Manga Reader:** Live health-monitored streaming servers (`Ryu`, `War`, `Warp`, `Volt`) plus verified chapter reader (`Honey` & `Sol`) with SSRF-hardened proxying.
- **Synchronized WebSocket Watch Parties:** Shareable room links with latency-calibrated host sync and live chat.
- **Windows Desktop Edition:** Electron wrapper (`electron/main.cjs`) and 1-click PowerShell/Batch installers (`public/install-kurostream.ps1`, `public/KuroStream.bat`).

## Development & Self-Hosting

```bash
npm install
cp .env.example .env
npm run dev
```

### Build & Verify

```bash
npm run lint
npm test
npm run build
npm start
```
